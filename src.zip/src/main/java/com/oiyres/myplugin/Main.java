package com.oiyres.myplugin;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.enchantments.Enchantment;

import java.util.Locale;

public final class Main extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        if (getCommand("take") != null) {
            getCommand("take").setExecutor(this);
        }
        getLogger().info(ChatColor.GREEN + "Плагин MaxEnchant успешно запущен! Разработчик: Ойрес.");
    }

    @Override
    public void onDisable() {
        getLogger().info(ChatColor.RED + "Плагин MaxEnchant выключен.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Эту команду могут использовать только игроки!");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("maxenchant.take")) {
            player.sendMessage(ChatColor.RED + "У вас нет прав на использование этой команды!");
            return true;
        }

        if (args.length < 2 || !args[1].equalsIgnoreCase("all")) {
            player.sendMessage(ChatColor.YELLOW + "Использование: /take <предмет> all");
            return true;
        }

        String materialName = args[0].toUpperCase(Locale.ROOT);
        Material material = Material.matchMaterial(materialName);

        if (material == null || material.isAir()) {
            player.sendMessage(ChatColor.RED + "Предмет с названием '" + args[0] + "' не найден!");
            return true;
        }

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            player.sendMessage(ChatColor.RED + "Этот предмет нельзя изменить или зачаровать!");
            return true;
        }

        int appliedCount = 0;
        for (Enchantment enchantment : Registry.ENCHANTMENT) {
            if (enchantment.canEnchantItem(item)) {
                int maxLevel = enchantment.getMaxLevel();
                meta.addEnchant(enchantment, maxLevel, true);
                appliedCount++;
            }
        }

        item.setItemMeta(meta);
        player.getInventory().addItem(item);
        player.sendMessage(ChatColor.GREEN + "Вам выдана " + material.name().toLowerCase(Locale.ROOT) + 
                " с " + appliedCount + " максимальными зачарованиями!");

        return true;
    }
}